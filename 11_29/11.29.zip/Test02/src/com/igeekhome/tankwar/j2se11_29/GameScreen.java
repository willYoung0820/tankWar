package com.igeekhome.tankwar.j2se11_29;

/**
 * ��Ϸ��Ļ
 * @author student
 *
 */
public class GameScreen {
	public static int V=800;
	
	public final static int SCREEN_WIDTH=800;
	public final static int SCREEN_HEIGHT=600;
	
	public final static int TANK_X_SPEED=10;
	public final static int TANK_y_SPEED=8;
	
	public final static int BULLET_SPEED=15;
}
