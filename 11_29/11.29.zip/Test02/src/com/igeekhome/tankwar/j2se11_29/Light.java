package com.igeekhome.tankwar.j2se11_29;

public interface Light {
	void open();
	void close();
}
