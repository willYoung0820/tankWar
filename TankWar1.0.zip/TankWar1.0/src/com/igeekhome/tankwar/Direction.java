package com.igeekhome.tankwar;

public enum Direction {
	L,R,U,D,STOP
}
