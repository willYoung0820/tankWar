package com.igeekhome.tankwar;


public class Demo01 {

	public static void main(String[] args) {
		GameClient gameClient=new GameClient();
		
	}

}
