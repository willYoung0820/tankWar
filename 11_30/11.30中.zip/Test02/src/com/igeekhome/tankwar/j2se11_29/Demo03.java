package com.igeekhome.tankwar.j2se11_29;

/**
 * 
 * @author student
 *
 */
public class Demo03 {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Direction dir=Direction.LU;
		System.out.println(dir);
	}

}
