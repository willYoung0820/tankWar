package com.igeekhome.tankwar.j2se11_29;

/**
 * ����
 * @author student
 *
 */
public enum Direction {
	L,R,U,D,LU,LD,RU,RD
}
