package com.igeekhome.tankwar.test;

import com.igeekhome.tankwar.j2se11_28.Rectangle;

public class Demo01 {

	public static void main(String[] args) {
		Rectangle r=new Rectangle();
	}

}
