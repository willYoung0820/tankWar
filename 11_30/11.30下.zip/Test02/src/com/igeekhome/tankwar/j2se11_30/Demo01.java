package com.igeekhome.tankwar.j2se11_30;

public class Demo01 {

	public static void main(String[] args) {
		GameClient gameClient=new GameClient();
		
	}

}
