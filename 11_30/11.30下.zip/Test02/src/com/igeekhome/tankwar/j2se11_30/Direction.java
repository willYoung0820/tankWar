package com.igeekhome.tankwar.j2se11_30;

public enum Direction {
	L,R,U,D,STOP
}
