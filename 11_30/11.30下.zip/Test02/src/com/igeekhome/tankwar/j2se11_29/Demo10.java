package com.igeekhome.tankwar.j2se11_29;

import java.util.ArrayList;
import java.util.Random;

/**
 * 
 * @author student
 *
 */
public class Demo10 {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {			
		Timer t=new Timer();
		t.start();
		
		
		
		System.out.println("-------------------------------------------------------------");
		
	}

}
