package com.igeekhome.tankwar.j2se11_29.homework;

public enum Direction {
	L,R,U,D
}
