package com.igeekhome.tankwar.j2se11_28;

/**
 * ̹����
 * @author student
 *
 */
public class Tank {
	
}
