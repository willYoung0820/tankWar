package com.igeekhome.tankwar.j2se11_29;


public class OP implements Light {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
