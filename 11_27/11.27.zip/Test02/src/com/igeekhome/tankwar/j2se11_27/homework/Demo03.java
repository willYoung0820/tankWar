package com.igeekhome.tankwar.j2se11_27.homework;

/**
 * 
 * @author student
 *
 */
public class Demo03 {

	/**
	 * ���9*9�˷��ھ���
	 * @param args
	 */
	public static void main(String[] args) {
		
		
	}

}
