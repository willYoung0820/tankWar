package com.igeekhome.tankwar.j2se11_28;

/**
 * 
 * @author student
 *
 */
public class Demo01 {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		//���ʹ�ã�ʵ����
		Dog hashiqi=new Dog();
		Dog taidi=new Dog();
		Dog bandian=new Dog();
		//
		hashiqi.setName("��ʿ��");
		hashiqi.cry();
		System.out.println(hashiqi.getName());
		
		taidi.setName("̩��");
		taidi.cry();
		System.out.println(taidi.getName());
	}

}
