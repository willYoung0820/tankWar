package com.igeekhome.tankwar.j2se11_28;

/**
 * 
 * @author student
 *
 */
public class Demo04 {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		//0<=   random  <1
		System.out.println(Math.random());
		
		//
		int[] arr1=new int[10];
		int[] arr2={1,5,6,8};
		
		System.out.println(arr1[0]);
		System.out.println(arr1[1]);
		System.out.println(arr2[0]);
		System.out.println(arr2[1]);
		
		
	}

}
